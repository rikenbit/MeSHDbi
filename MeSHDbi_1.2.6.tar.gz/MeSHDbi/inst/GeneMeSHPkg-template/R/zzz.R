.onLoad <- function(libname, pkgname) {
  MeSHDbi:::.loadMeSHDbiPkg(pkgname=pkgname)
}
