##
## Definition of Generic Functions
##

setGeneric("packageName", function(x) standardGeneric("packageName"))
setGeneric("nomenclature", function(x) standardGeneric("nomenclature"))
setGeneric("listDatabases", function(x) standardGeneric("listDatabases"))
setGeneric("meshVersion", function(x) standardGeneric("meshVersion"))
